package com.dailycodework.dreamshops.enums;

public enum CouponType {
    PERCENTAGE, FLAT
}
